#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <limits>
#include <algorithm>
using namespace std;

void addedSuccessfully(string show);
void deletedSuccessfully(string show);
void noMore(string show);
void alreadyInWL(string show);