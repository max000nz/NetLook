#pragma once
#include "user.h"
#include "admin.h"
using namespace std;

void userMenu(User user);
void adminMenu(Admin admin);


